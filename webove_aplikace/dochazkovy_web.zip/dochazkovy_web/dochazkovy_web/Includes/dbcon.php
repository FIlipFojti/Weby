<?php
	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "maturita_web";
	
	$conn = new mysqli($host, $user, $pass, $db);
	if($conn->connect_error){
		echo "Chyba databáze" . $conn->connect_error;
	}
?>