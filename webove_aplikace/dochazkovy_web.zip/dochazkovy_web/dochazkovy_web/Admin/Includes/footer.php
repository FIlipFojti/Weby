<!-- Footer -->
<div class="container">
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <div class="col-md-6">
            <p class="mb-0 text-muted">&copy; 2023 Fojtík Filip 4.AI </p>
            <a href="https://skolabaltaci.cz/">Škola Baltaci</a>
        </div>
        <div class="col-md-6">
            <p class="mb-0 text-muted">Webová aplikace byla vytvořena za účelem maturitního projektu a nápomoci
                učitelům odborného výcviku zapisování docházky studentů.</p>
            <p class="mb-0 text-muted">Všechna data jsou fiktivní.</p>
        </div>
    </footer>
</div>