
<?php
error_reporting(0);
include '../Includes/dbcon.php';
include '../Includes/session.php';


if(isset($_POST['save'])){

    $firstName=$_POST['firstName'];
    $lastName=$_POST['lastName'];
    $otherName=$_POST['otherName'];

    $admissionNumber=$_POST['admissionNumber'];
    $classId=$_POST['classId'];
    $dateCreated = date("Y-m-d");

    $query=mysqli_query($conn,"select * from tblstudents where admissionNumber ='$admissionNumber'");
    $ret=mysqli_fetch_array($query);

    if($ret > 0){

        $statusMsg = "<div class='alert alert-danger' style='margin-right:700px;'>Emailová adresa existuje</div>";
    }
    else{

        $query=mysqli_query($conn,"insert into tblstudents(firstName,lastName,otherName,admissionNumber,password,classId,classArmId,dateCreated) 
    value('$firstName','$lastName','$otherName','$admissionNumber','12345','$classId','$dateCreated')");

        if ($query) {

            $statusMsg = "<div class='alert alert-success'  style='margin-right:700px;'>Úspěšně vytvořeno</div>";

        }
        else
        {
            $statusMsg = "<div class='alert alert-danger' style='margin-right:700px;'>Chyba</div>";
        }
    }
}

if (isset($_GET['Id']) && isset($_GET['action']) && $_GET['action'] == "edit")
{
    $Id= $_GET['Id'];

    $query=mysqli_query($conn,"select * from tblstudents where Id ='$Id'");
    $row=mysqli_fetch_array($query);


    if(isset($_POST['update'])){

        $firstName=$_POST['firstName'];
        $lastName=$_POST['lastName'];
        $otherName=$_POST['otherName'];

        $admissionNumber=$_POST['admissionNumber'];
        $classId=$_POST['classId'];
        $dateCreated = date("Y-m-d");

        $query=mysqli_query($conn,"update tblstudents set firstName='$firstName', lastName='$lastName',
    otherName='$otherName', admissionNumber='$admissionNumber',password='12345', classId='$classId',
    where Id='$Id'");
        if ($query) {

            echo "<script type = \"text/javascript\">
                window.location = (\"createStudents.php\")
                </script>";
        }
        else
        {
            $statusMsg = "<div class='alert alert-danger' style='margin-right:700px;'>Chyba</div>";
        }
    }
}

if (isset($_GET['Id']) && isset($_GET['action']) && $_GET['action'] == "delete")
{
    $Id= $_GET['Id'];

    $query = mysqli_query($conn,"DELETE FROM tblstudents WHERE Id='$Id'");

    if ($query == TRUE) {

        echo "<script type = \"text/javascript\">
            window.location = (\"createStudents.php\")
            </script>";
    }
    else{

        $statusMsg = "<div class='alert alert-danger' style='margin-right:700px;'>Chyba</div>";
    }

}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Student</title>
    <link href="img/logo/logo.jpg" rel="icon">
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/admin.min.css" rel="stylesheet">



    <script>
        function classArmDropdown(str) {
            if (str == "") {
                document.getElementById("txtHint").innerHTML = "";
                return;
            } else {
                if (window.XMLHttpRequest) {
                    xmlhttp = new XMLHttpRequest();
                } else {
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("txtHint").innerHTML = this.responseText;
                    }
                };

            }
        }
    </script>
</head>

<body id="page-top">
<div id="wrapper">
    <!-- Boční panel -->
    <?php include "Includes/sidebar.php";?>
    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <!-- Horní panel -->
            <?php include "Includes/topbar.php";?>

            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <div class="container-fluid" id="container-wrapper">
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Návod k použití aplikace</h1>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="./">Domů</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Návod</li>
                            </ol>
                        </div>
                    </div>

            <div class="row mb-3">
                <div class="p-5 mb-4 bg-light rounded-3">
                    <div class="container-fluid py-5">
                        <h1 class="display-5 fw-bold">Docházkový web pro učitele odborného výcviku</h1>
                        <p class="col-md-8 fs-4">Webová aplikace umožňuje zápis docházky a základní správu informací o průběhu odborného výcviku.</p>
                    </div>
                </div>
                <div class="row align-items-md-stretch">
                    <div class="col-md-6">
                        <div class="h-100 p-5 text-bg-dark rounded-3">
                            <h2>Upravit třídu</h2>
                            <p>V sekci upravit třídu můžeme jako administrátor vytvořit další třídu.</p>
                            <p>Vybereme pouze název třídy. Třída se nám zobrazí v tabulce níže. Je možné trídu smazat nebo upravit.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="h-100 p-5 bg-light border rounded-3">
                            <h2>Upravit učitele</h2>
                            <p>V sekci upravit učitele máme možnost vytvořit nového uživatele jako učitele.</p>
                            <p>V tabulce níže máme seznam učitelů a jejich vlastnosti. Máme možnost smazat učitele.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="h-100 p-5 bg-light border rounded-3">
                            <h2>Upravit studenta</h2>
                            <p>V sekci upravit studenta máme možnost vytvořit a přidat studenta. Vybereme třídu do které chceme studenta přiřadit.</p>
                            <p>V tabulce níže máme seznam studentů a jejich vlasstnosti. Máme možnost studenta upravit nebos smazat</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="h-100 p-5 text-bg-dark rounded-3">
                            <h2>Odhlásit se</h2>
                            <p>Po stistknutí tlačítka "Odhlásit se", aplikace odhlásí uživatele a nebude moci dále pokračovat v užívání, dokud se opět nepřihlásí.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <?php include "Includes/footer.php";?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/admin.min.js"></script>
    <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function () {
            $('#dataTable').DataTable();
            $('#dataTableHover').DataTable();
        });
    </script>
</body>

</html>