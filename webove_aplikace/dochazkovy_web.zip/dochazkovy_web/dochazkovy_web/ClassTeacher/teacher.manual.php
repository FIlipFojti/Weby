
<?php
include '../Includes/dbcon.php';
include '../Includes/session.php';


$query = "SELECT tblclass.className,tblclassarms.classArmName 
    FROM tblclassteacher
    INNER JOIN tblclass ON tblclass.Id = tblclassteacher.classId
    INNER JOIN tblclassarms ON tblclassarms.Id = tblclassteacher.classArmId
    Where tblclassteacher.Id = '$_SESSION[userId]'";

$rs = $conn->query($query);
$num = $rs->num_rows;
$rrw = $rs->fetch_assoc();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="img/logo/logo.jpg" rel="icon">
    <title>Úvod</title>
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/u-admin.min.css" rel="stylesheet">
</head>

<body id="page-top">
<div id="wrapper">
    <!-- Boční panel -->
    <?php include "Includes/sidebar.php";?>
    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <!-- Horní panel -->
            <?php include "Includes/topbar.php";?>

            <div class="container-fluid" id="container-wrapper">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Návod k použití aplikace</h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="./">Domů</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Manual</li>
                    </ol>
                </div>
                <div>
                    <div class="row mb-3">
                        <div class="p-5 mb-4 bg-light rounded-3">
                            <div class="container-fluid py-5">
                                <h1 class="display-5 fw-bold">Docházkový web pro učitele odborného výcviku</h1>
                                <p class="col-md-8 fs-4">Webová aplikace umožňuje zápis docházky a základní správu informací o průběhu odborného výcviku.</p>
                            </div>
                        </div>
                        <div class="row align-items-md-stretch">
                            <div class="col-md-6">
                                <div class="h-100 p-5 text-bg-dark rounded-3">
                                    <h2>Studenti</h2>
                                    <p>V sekci studenti se nám zobrazí všichni studenti v naší třídě.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="h-100 p-5 bg-light border rounded-3">
                                    <h2>Docházka</h2>
                                    <p>V sekci docházka máme na výběr mezi 4 možnostmi.</p>
                                    <p>První možnost. Zobrazíme si docházku studentů.</p>
                                    <p>Druhá možnost. Zobrazit třídní docházku. Vybereme datum, který potřebujeme a stiskneme tlačítko zobrazit docházku. Níže v tabulce se nám zobrazí docházka celé třídy.</p>
                                    <p>Třetí možnost. Zobrazit docházku daného studenta. Vybereme jméno a možnost který den.</p>
                                    <p>Čtvrtá možnost. Stáhneme si Excel tabulku, která nám vygeneruje docházku třídy.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="h-100 p-5 text-bg-dark rounded-3">
                                    <h2>Odhlásit se</h2>
                                    <p>Po stisknutí tlačítka "Odhlásit se", aplikace odhlásí uživatele a nebude moci dále pokračovat v užívání, dokud se opět nepřihlásí.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <?php include 'includes/footer.php';?>
            </div>
        </div>

        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
        <script src="js/ruang-admin.min.js"></script>
        <script src="../vendor/chart.js/Chart.min.js"></script>
        <script src="js/demo/chart-area-demo.js"></script>
</body>

</html>